# Title: Financing Healthcare

### Project Description:
This project seeks to highlight the effect that a country's willingness to invest in healthcare has on certain population indicators such as life expectancy. 

### Tools
- MySQL
- Tableau Public

### Data Description:
1. **Annual healthcare expenditure**

Contains the annual CHE for each country, geographical region and high/low income regions from 2000 -2019

2. **Life expectancy by country**

Contains the life expectancy of males and females in each country in 2000,2010,2015 & 2019

3. **Life expectancy by WHO region**

Contains the life expectancy of males and females in each WHO classified geographical region in 2000,2010,2015 & 2019


### Data Sources
- [Kaggle](https://www.kaggle.com/datasets/programmerrdai/financing-healthcare)
- [WHO data bank](https://www.who.int/data/gho/data/indicators/indicators-index)
### Measure Definitions
**CHE per capita :** Stands for Current Health Expenditure per capita. This indicator calculates the average expenditure on health per person in comparable currency including the purchasing power of national currencies against USD. It contributes to understand the health expenditure relative to the population size facilitating international comparison.

[Source: WHO Website](https://www.who.int/data/gho/indicator-metadata-registry/imr-details/4952#:~:text=Associated%20Indicators-,Current%20health%20expenditure%20(CHE)%20per%20capita%20in%20PPP%20int%24,of%20national%20currencies%20against%20USD.)

### SQL Objectives
- Determine average regional CHE over 10 years (2010 -2019)
- Determine regional life expectancy for males and females over 10 years (2010-2019)
- Determine national CHE_per_capita over 10 years (2010 -2019)
- Determine national life expectancy for males and females over 10 years (2010 -2019)
- Rank the nations by their average CHE_per_capita
- Rank the WHO regions by their average CHE_per_capita




```python

```
